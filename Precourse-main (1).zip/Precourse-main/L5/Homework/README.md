# Homework #JSII

## Instructions
---
1. Feynman Writing Prompts - Write out explanations of the following concepts like you are explaining it to a 12 year old.  Doing this will help you quickly discover any holes in your understanding.  Ask your questions on Slack.
		
	* `for`
	* `&&`, `||`, `!`

2. From the top level of your `Precourse` folder, run `npm test L5/Homework/tests/JSII.test.js` to run the automated tests. You will fill out the functions in `homework.js` to make the tests pass.
